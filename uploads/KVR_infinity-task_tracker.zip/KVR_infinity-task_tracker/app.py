from flask import Flask, render_template, redirect, url_for, request, flash, g
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from flask_mail import Mail, Message
from datetime import datetime

DATABASE = 'tracker.db'

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here'

# Configure Flask-Mail (use your actual email credentials)
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'your_gmail@gmail.com'      # Replace with your Gmail
app.config['MAIL_PASSWORD'] = 'your_gmail_app_password'   # Use App Password if 2FA is enabled
mail = Mail(app)

# --- Database Helpers ---
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def query_db(query, args=(), one=False, commit=False):
    cur = get_db().execute(query, args)
    rv = cur.fetchall()
    cur.close()
    if commit:
        get_db().commit()
    return (rv[0] if rv else None) if one else rv

# --- Create Tables ---
def create_tables():
    db = get_db()
    db.execute("""
        CREATE TABLE IF NOT EXISTS user (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            role TEXT NOT NULL DEFAULT 'user'
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS department (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE
        )
    """)
    db.execute("""
        CREATE TABLE IF NOT EXISTS task (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_name TEXT NOT NULL,
            job_number TEXT NOT NULL,
            department_id INTEGER NOT NULL,
            job_description TEXT NOT NULL,
            status TEXT DEFAULT 'Pending',
            edc DATE NOT NULL,
            due_date DATE NOT NULL,
            spoc TEXT NOT NULL,
            FOREIGN KEY (department_id) REFERENCES department(id)
        )
    """)
    db.commit()

# --- Seed Departments ---
@app.before_request
def seed_departments():
    departments = [
        'IT Department', 'Marketing Department', 'Graphic Designers',
        'Operations', 'Finance', 'HR', 'Sales',
        'Business Analyst', 'Executive Department'
    ]
    for name in departments:
        exists = query_db("SELECT id FROM department WHERE name = ?", [name], one=True)
        if not exists:
            query_db("INSERT INTO department (name) VALUES (?)", [name], commit=True)

# --- Routes ---
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/home")
def home():
    return render_template("home.html")

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form.get('role', 'user')
        user = query_db("SELECT * FROM user WHERE username = ?", [username], one=True)
        if user:
            flash('Username already exists')
            return redirect(url_for('signup'))
        hashed_pw = generate_password_hash(password)
        query_db(
            "INSERT INTO user (username, password, role) VALUES (?, ?, ?)",
            [username, hashed_pw, role], commit=True
        )
        flash('Account created! Please log in.')
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = query_db("SELECT * FROM user WHERE username = ?", [username], one=True)
        if user and check_password_hash(user['password'], password):
            from flask import session
            session['username'] = username
            session['role'] = user['role']
            flash('Logged in successfully!')
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Invalid credentials')
    return render_template('login.html')

@app.route('/admin/dashboard', methods=['GET', 'POST'])
def admin_dashboard():
    departments = query_db("SELECT * FROM department")
    tasks = query_db("""
        SELECT task.*, department.name AS department_name
        FROM task
        JOIN department ON task.department_id = department.id
        ORDER BY task.id DESC
    """)
    if request.method == 'POST':
        project_name = request.form['project_name']
        job_number = request.form['job_number']
        department_id = request.form['department_id']
        job_description = request.form['job_description']
        edc = request.form['edc']
        due_date = request.form['due_date']
        spoc = request.form['spoc']
        query_db("""
            INSERT INTO task
            (project_name, job_number, department_id, job_description, edc, due_date, spoc)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, [
            project_name, job_number, department_id, job_description, 
            edc, due_date, spoc
        ], commit=True)
        flash('Task assigned successfully!')
        return redirect(url_for('admin_dashboard'))
    
    
    # Fetch tasks for display
    tasks = query_db("""
        SELECT task.*, department.name AS department_name 
        FROM task 
        JOIN department ON task.department_id = department.id
        ORDER BY task.id DESC
    """)
    return render_template('admin_dashboard.html', departments=departments, tasks=tasks)


# --- Superadmin Dashboard ---
@app.route('/superadmin/dashboard', methods=['GET', 'POST'])
def superadmin_dashboard():
    departments = query_db("SELECT * FROM department")
    admins = query_db("SELECT * FROM user WHERE role='admin'")
    tasks = query_db("""
        SELECT task.*, department.name AS department_name
        FROM task
        JOIN department ON task.department_id = department.id
        ORDER BY task.id DESC
    """)
    if request.method == 'POST':
        if 'create_admin' in request.form:
            username = request.form['admin_username']
            password = request.form['admin_password']
            email = request.form['admin_email']
            if query_db("SELECT * FROM user WHERE username = ? OR email = ?", [username, email], one=True):
                flash('Admin username or Gmail already exists!', 'danger')
            else:
                hashed_pw = generate_password_hash(password)
                query_db(
                    "INSERT INTO user (username, password, email, role) VALUES (?, ?, ?, ?)",
                    [username, hashed_pw, email, 'admin'], commit=True
                )
                flash('Admin created successfully!', 'success')
            return redirect(url_for('superadmin_dashboard'))
        else:
            project_name = request.form['project_name']
            job_number = request.form['job_number']
            department_id = request.form['department_id']
            job_description = request.form['job_description']
            status = request.form['status']
            edc = request.form['edc']
            due_date = request.form['due_date']
            spoc = request.form['spoc']
            query_db("""
                INSERT INTO task
                (project_name, job_number, department_id, job_description, status, edc, due_date, spoc)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, [
                project_name, job_number, department_id, job_description, status,
                edc, due_date, spoc
            ], commit=True)
            
            # Send credentials to the new admin's Gmail
            try:
                    msg = Message(
                        subject="Your Admin Account Credentials",
                        sender=app.config['MAIL_USERNAME'],
                        recipients=[email]
                    )
                    msg.body = f"""Hello,

You have been added as an Admin by the Superadmin.

Your login credentials are:
Username: {username}
Password: {password}

Please login at http://localhost:8000/admin/login

Regards,
Task Progress Tracker Team
"""
                    mail.send(msg)
                    flash('Admin created and credentials sent to Gmail!', 'success')
            except Exception as e:
                    flash(f'Admin created, but failed to send email: {e}', 'danger')
            flash('Task assigned successfully!', 'success')
            return redirect(url_for('superadmin_dashboard'))
    return render_template('superadmin_dashboard.html', departments=departments, admins=admins, tasks=tasks)



@app.route('/superadmin/admin/edit/<int:admin_id>', methods=['GET', 'POST'])
def edit_admin(admin_id):
    admin = query_db("SELECT * FROM user WHERE id=? AND role='admin'", [admin_id], one=True)
    if not admin:
        flash('Admin not found!', 'danger')
        return redirect(url_for('superadmin_dashboard'))
    if request.method == 'POST':
        username = request.form['admin_username']
        email = request.form['admin_email']
        password = request.form['admin_password']
        # Check if username is taken by another admin
        existing = query_db("SELECT * FROM user WHERE username=? AND id!=?", [username,admin_id], one=True)
        if existing:
            flash('Username already taken by another admin!', 'danger')
            return redirect(url_for('edit_admin', admin_id=admin_id))
        
        # Check if email is taken by another admin
        existing_email = query_db("SELECT * FROM user WHERE email=? AND id!=?", [email, admin_id], one=True)
        if existing_email:
            flash('Email already taken by another admin!', 'danger')
            return redirect(url_for('edit_admin', admin_id=admin_id))
        # Update admin
        if password.strip():
            hashed_pw = generate_password_hash(password)
            query_db("UPDATE user SET username=?, password=? WHERE id=?", [username, hashed_pw, admin_id], commit=True)
        else:
            query_db("UPDATE user SET username=?email=? WHERE id=?", [username, email, admin_id], commit=True)
        flash('Admin updated successfully!', 'success')
        return redirect(url_for('superadmin_dashboard'))
    return render_template('edit_admin.html', admin=admin)

@app.route('/superadmin/admin/delete/<int:admin_id>', methods=['POST'])
def delete_admin(admin_id):
    query_db("DELETE FROM user WHERE id=? AND role='admin'", [admin_id], commit=True)
    flash('Admin deleted successfully!', 'success')
    return redirect(url_for('superadmin_dashboard'))

@app.route('/admin/task/delete/<int:task_id>', methods=['POST'])
def delete_task(task_id):
    query_db("DELETE FROM task WHERE id = ?", [task_id], commit=True)
    flash('Task deleted successfully!')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/task/update/<int:task_id>', methods=['GET', 'POST'])
def update_task(task_id):
    task = query_db("SELECT * FROM task WHERE id = ?", [task_id], one=True)
    departments = query_db("SELECT * FROM department")
    if not task:
        flash('Task not found!')
        return redirect(url_for('admin_dashboard'))
    if request.method == 'POST':
        project_name = request.form['project_name']
        job_number = request.form['job_number']
        department_id = request.form['department_id']
        job_description = request.form['job_description']
        edc = request.form['edc']
        due_date = request.form['due_date']
        spoc = request.form['spoc']
        query_db("""
            UPDATE task SET project_name=?, job_number=?, department_id=?, job_description=?, edc=?, due_date=?, spoc=?
            WHERE id=?
        """, [
            project_name, job_number, department_id, job_description,
            edc, due_date, spoc, task_id
        ], commit=True)
        flash('Task updated successfully!')
        return redirect(url_for('admin_dashboard'))
    return render_template('update_task.html', task=task, departments=departments)

# --- Initialize Database ---
if __name__ == "__main__":
    with app.app_context():
        create_tables()
    app.run(debug=True, port=8000)
