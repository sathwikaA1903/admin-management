import sqlite3

conn = sqlite3.connect('tracker.db')
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS user (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE
    password TEXT,
    role TEXT NOT NULL DEFAULT 'user',
    email TEXT UNIQUE
);
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS department (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
);
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS task (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_name TEXT NOT NULL,
    job_number TEXT NOT NULL,
    department_id INTEGER NOT NULL,
    job_description TEXT NOT NULL,
    edc DATE NOT NULL,
    due_date DATE NOT NULL,
    spoc TEXT NOT NULL,
    FOREIGN KEY (department_id) REFERENCES department(id)
);
""")

conn.commit()
conn.close()

print("Database and tables created successfully.")